using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Developed.PrefabPool;

namespace Game.ECS.ObjectPool
{
    public class ExternalPoolAdapter : IGameObjectCreationProvider
    {
        private IPrefabPoolExternal prefabPoolExternal;


        public ExternalPoolAdapter(IPrefabPoolExternal prefabPoolExternal)
        {
            this.prefabPoolExternal = prefabPoolExternal;
        }


        public GameObject GetNew(GameObject prefab)
        {
            return prefabPoolExternal.GetNew(prefab);
        }

        public void SetFree(GameObject gameObject)
        {
            prefabPoolExternal.SetFree(gameObject);
        }
    }
}