using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Game.ECS.ObjectPool
{
    public class SimpleGameObjectCreation : MonoBehaviour, IGameObjectCreationProvider
    {
        public GameObject GetNew(GameObject prefab)
        {
            return Instantiate(prefab, transform);
        }

        public void SetFree(GameObject gameObject)
        {
            Destroy(gameObject);
        }
    }
}