using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leopotam.Ecs;

namespace Game.ECS.ScriptableObjects
{
    public abstract class ScriptableEntitySpawnProvider : ScriptableObject, IEntitySpawnProvider
    {
        [Tooltip("Reference to prefab used as an object in game")]
        [SerializeField] private GameObject gameObjectPrefab;


        public GameObject GetNewGameObject(ISceneContext sceneContext, Vector3 position, Vector2 direction)
        {
            var gameObject = GetPrefabPool(sceneContext).GetNew(gameObjectPrefab);

            gameObject.transform.localPosition = position;
            gameObject.transform.up = direction;

            return gameObject;
        }


        public abstract void SetEntityComponents(in EcsEntity ecsEntity, GameObject gameObject);

        protected virtual IGameObjectCreationProvider GetPrefabPool(ISceneContext sceneContext) => sceneContext.spaceEntitiesPool;
    }
}