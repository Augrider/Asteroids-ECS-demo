using Leopotam.Ecs;

namespace Game.ECS.Components
{
    [System.Serializable]
    public struct InputComponent
    {
        public float maxAcceleration;
        public float rotationSpeed;
    }
}