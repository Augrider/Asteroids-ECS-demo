namespace Game.ECS.Components
{
    [System.Serializable]
    public struct DestroyOnHitComponent { }
}