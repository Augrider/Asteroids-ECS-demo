namespace Game.ECS.Components
{
    [System.Serializable]
    public struct ScoreComponent
    {
        public int value;
    }
}