using UnityEngine;

namespace Game.ECS.Components
{
    [System.Serializable]
    public struct SpawnOnDeathComponent
    {
        public IEntitySpawnProvider spawnProvider;
        public int amount;
    }
}