using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public class TransformProvider : MonoProvider<TransformComponent> { }
}