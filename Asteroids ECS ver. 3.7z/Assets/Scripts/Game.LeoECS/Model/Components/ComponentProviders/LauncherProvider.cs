using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public class LauncherProvider : MonoProvider<ProjectileLauncher> { }
}