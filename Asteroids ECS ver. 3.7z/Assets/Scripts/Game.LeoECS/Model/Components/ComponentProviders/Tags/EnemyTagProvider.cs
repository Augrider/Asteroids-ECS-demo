using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public class EnemyTagProvider : MonoProvider<Enemy> { }
}