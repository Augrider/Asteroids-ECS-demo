using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public class EnemyOwnedProvider : MonoProvider<EnemyOwned> { }
}