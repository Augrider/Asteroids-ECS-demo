using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public class PlayerOwnedProvider : MonoProvider<PlayerOwned> { }
}