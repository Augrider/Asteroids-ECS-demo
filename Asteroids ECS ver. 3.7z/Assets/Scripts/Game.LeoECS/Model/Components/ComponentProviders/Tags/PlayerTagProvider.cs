using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public class PlayerTagProvider : MonoProvider<Player> { }
}