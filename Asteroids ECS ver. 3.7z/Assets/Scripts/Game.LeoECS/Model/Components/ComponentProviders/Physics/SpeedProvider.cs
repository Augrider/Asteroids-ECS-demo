using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public sealed class SpeedProvider : MonoProvider<SpeedComponent> { }
}