using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public sealed class RotationProvider : MonoProvider<RotationComponent> { }
}