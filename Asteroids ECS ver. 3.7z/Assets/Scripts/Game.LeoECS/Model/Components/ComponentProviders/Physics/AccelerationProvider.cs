using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public sealed class AccelerationProvider : MonoProvider<AccelerationComponent> { }
}