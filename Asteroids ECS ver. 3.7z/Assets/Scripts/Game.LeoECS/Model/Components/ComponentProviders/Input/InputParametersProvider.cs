using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public class InputParametersProvider : MonoProvider<InputComponent> { }
}