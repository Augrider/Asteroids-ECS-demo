using Voody.UniLeo;

namespace Game.ECS.Components.Providers
{
    public class LifetimeProvider : MonoProvider<LifetimeComponent> { }
}