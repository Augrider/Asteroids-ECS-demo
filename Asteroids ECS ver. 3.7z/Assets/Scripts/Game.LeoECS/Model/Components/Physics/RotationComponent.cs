namespace Game.ECS.Components
{
    [System.Serializable]
    public struct RotationComponent
    {
        public float rotationSpeed;
    }
}