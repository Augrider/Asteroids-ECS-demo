using Leopotam.Ecs;

namespace Game.ECS.Components
{
    [System.Serializable]
    public struct Enemy : IEcsIgnoreInFilter
    { }
}