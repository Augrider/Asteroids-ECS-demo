using System.Collections;
using System.Collections.Generic;
using Leopotam.Ecs;
using UnityEngine;
using Game.ECS.Components;

namespace Game.ECS.ScriptableObjects
{
    [CreateAssetMenu(menuName = "ECS/Weapons/Beam Weapon")]
    public class BeamWeaponData : WeaponData
    {
        [Range(0.1f, 10f)]
        public float lifetime;

        [Header("Optional parameters")]
        public bool destroyOnHit;


        public override void SetEntityComponents(in EcsEntity ecsEntity, GameObject gameObject)
        {
            base.SetEntityComponents(in ecsEntity, gameObject);

            AddDespawnModifiers(in ecsEntity, lifetime, destroyOnHit);

            ecsEntity.Replace(new LifetimeComponent() { lifetimeSec = lifetime });
        }
    }
}