using System.Collections;
using System.Collections.Generic;
using Leopotam.Ecs;
using UnityEngine;
using Game.ECS.Components;
using System;

namespace Game.ECS.ScriptableObjects
{
    [CreateAssetMenu(menuName = "ECS/Weapons/Projectile Weapon")]
    public class ProjectileWeaponData : WeaponData
    {
        public float projectileSpeed;

        [Header("Optional parameters")]
        public float lifetime;
        public bool destroyOnHit;


        public override void SetEntityComponents(in EcsEntity ecsEntity, GameObject gameObject)
        {
            base.SetEntityComponents(in ecsEntity, gameObject);

            ref var transformComponent = ref ecsEntity.Get<TransformComponent>();
            ecsEntity.Replace(new SpeedComponent() { speed = this.projectileSpeed * transformComponent.rotationTransform.up });

            AddDespawnModifiers(in ecsEntity, lifetime, destroyOnHit);
        }
    }
}