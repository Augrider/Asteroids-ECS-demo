using System;
using System.Collections;
using System.Collections.Generic;
using Game.ECS.Components;
using Leopotam.Ecs;
using UnityEngine;

namespace Game.ECS.ScriptableObjects
{
    //TODO: Inspector UI or encapsulate individual components into SO for easy components change instead of inheritance
    public abstract class SpaceEntityData : ScriptableEntitySpawnProvider
    {
        public int spawnScoreCost;
        public int killScoreCost;
        protected abstract bool isPlayer { get; }


        public override void SetEntityComponents(in EcsEntity ecsEntity, GameObject gameObject)
        {
            var transformComponent = new TransformComponent() { entityTransform = gameObject.transform, rotationTransform = gameObject.transform };

            ecsEntity.Replace(in transformComponent);
            ecsEntity.Replace(new ScoreComponent() { value = this.killScoreCost });

            ref var speedComponent = ref ecsEntity.Get<SpeedComponent>();
            ref var rotationComponent = ref ecsEntity.Get<RotationComponent>();

            AddSpaceEntityTag(in ecsEntity, isPlayer);
            SetEntitySpeed(in transformComponent, ref speedComponent, ref rotationComponent);
        }



        private void AddSpaceEntityTag(in EcsEntity ecsEntity, bool isPlayer)
        {
            if (isPlayer)
                ecsEntity.Get<Player>();
            else
                ecsEntity.Get<Enemy>();
        }


        protected virtual void SetEntitySpeed(in TransformComponent transformComponent, ref SpeedComponent speedComponent, ref RotationComponent rotationComponent) { }
    }
}