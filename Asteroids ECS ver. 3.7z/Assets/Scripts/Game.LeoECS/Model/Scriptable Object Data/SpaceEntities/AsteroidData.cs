using System.Collections;
using System.Collections.Generic;
using Leopotam.Ecs;
using UnityEngine;
using Game.ECS.Components;

namespace Game.ECS.ScriptableObjects
{
    [CreateAssetMenu(menuName = "ECS/Space Entities/Asteroid")]
    public class AsteroidData : SpaceEntityData
    {
        protected override bool isPlayer => false;

        public float speed;
        public float rotationSpeed;


        [Header("Optional parameters")]
        public ScriptableEntitySpawnProvider spawnOnDeath;
        public int spawnAmount;

        public float speedDelta;
        public float rotationSpeedDelta;


        public override void SetEntityComponents(in EcsEntity ecsEntity, GameObject gameObject)
        {
            base.SetEntityComponents(ecsEntity, gameObject);

            if (spawnOnDeath != null && spawnAmount > 0)
                ecsEntity.Replace(new SpawnOnDeathComponent() { spawnProvider = this.spawnOnDeath, amount = this.spawnAmount });
        }


        protected override void SetEntitySpeed(in TransformComponent transformComponent, ref SpeedComponent speedComponent, ref RotationComponent rotationComponent)
        {
            speedComponent.speed = GetSpeed(in transformComponent, speed, speedDelta);
            rotationComponent.rotationSpeed = GetRotationSpeed(rotationSpeed, rotationSpeedDelta);
        }



        private Vector2 GetSpeed(in TransformComponent transform, float value, float delta)
        {
            var speed = delta * Random.Range(-1f, 1f);
            speed += value;

            return transform.entityTransform.up * speed;
        }

        private float GetRotationSpeed(float value, float delta)
        {
            var rotationSpeed = delta * Random.Range(-1f, 1f);
            rotationSpeed += value;

            return rotationSpeed;
        }
    }
}