using System.Collections;
using System.Collections.Generic;
using Leopotam.Ecs;
using UnityEngine;
using Game.ECS.Components;

namespace Game.ECS.ScriptableObjects
{
    [CreateAssetMenu(menuName = "ECS/Space Entities/Saucer")]
    public class SaucerData : SpaceEntityData
    {
        protected override bool isPlayer => false;

        public float rotationSpeed;

        public float baseSpeed;
        public float playerDistanceMultiplier;


        public override void SetEntityComponents(in EcsEntity ecsEntity, GameObject gameObject)
        {
            base.SetEntityComponents(ecsEntity, gameObject);

            ecsEntity.Replace(new ChasePlayerComponent() { baseSpeed = this.baseSpeed, playerDistanceMultiplier = this.playerDistanceMultiplier });
        }


        protected override void SetEntitySpeed(in TransformComponent transformComponent, ref SpeedComponent speedComponent, ref RotationComponent rotationComponent)
        {
            rotationComponent.rotationSpeed = rotationSpeed;
        }
    }
}