using System.Collections;
using System.Collections.Generic;
using Leopotam.Ecs;
using UnityEngine;
using Game.ECS.Components;

namespace Game.ECS.ScriptableObjects
{
    [CreateAssetMenu(menuName = "ECS/Space Entities/Player")]
    public class PlayerData : SpaceEntityData
    {
        protected override bool isPlayer => true;

        public float dragValue;
        public float dragSpeedMultiplier;

        public float maxAcceleration;
        public float rotationSpeed;


        public override void SetEntityComponents(in EcsEntity ecsEntity, GameObject gameObject)
        {
            base.SetEntityComponents(ecsEntity, gameObject);

            ecsEntity.Replace(new AccelerationComponent() { dragValue = this.dragValue, dragSpeedMultiplier = this.dragSpeedMultiplier });
            ecsEntity.Replace(new InputComponent() { maxAcceleration = this.maxAcceleration, rotationSpeed = this.rotationSpeed });
        }
    }
}