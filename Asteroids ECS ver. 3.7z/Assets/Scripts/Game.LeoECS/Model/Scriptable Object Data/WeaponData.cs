using System.Collections;
using System.Collections.Generic;
using Game.ECS.Components;
using Leopotam.Ecs;
using Developed.ScriptableObjects.Variables;
using UnityEngine;
using System;

namespace Game.ECS.ScriptableObjects
{
    public abstract class WeaponData : ScriptableEntitySpawnProvider, IWeaponProvider, IEntitySpawnProvider
    {
        public IEntitySpawnProvider projectileSpawn => this;

        public int maxCharges => _maxCharges;
        public float fullChargeCooldown => _fullChargeCooldown;
        public float fireCooldown => _fireCooldown;

        [SerializeField] private int _maxCharges = 2;
        [SerializeField] private float _fullChargeCooldown = 0.5f;
        [SerializeField] private float _fireCooldown = 1;

        protected virtual bool isPlayerOwned => true;


        public EcsEntity CreateWeaponState(EcsWorld world, in EcsEntity owner)
        {
            var entity = world.NewEntity();

            ref var weaponState = ref entity.Get<WeaponStateComponent>();

            weaponState.weaponProvider = this;
            weaponState.owner = owner;

            weaponState.fireCooldown = fireCooldown;
            weaponState.fullChargeCooldown = fullChargeCooldown;
            weaponState.maxCharges = maxCharges;

            return entity;
        }

        public override void SetEntityComponents(in EcsEntity ecsEntity, GameObject gameObject)
        {
            ecsEntity.Replace(new TransformComponent() { entityTransform = gameObject.transform, rotationTransform = gameObject.transform });

            AddProjectileTag(in ecsEntity, isPlayerOwned);
        }


        protected sealed override IGameObjectCreationProvider GetPrefabPool(ISceneContext sceneContext) => sceneContext.projectilesPool;

        /// <summary>
        /// Add additional components that add new despawn conditions
        /// </summary>
        /// <remarks>
        /// Generally projectile should despawn if invisible (out of bounds) for certain time
        /// And beams should despawn after specified lifetime
        /// </remarks>
        protected void AddDespawnModifiers(in EcsEntity ecsEntity, float lifetime, bool destroyOnHit)
        {
            if (destroyOnHit)
                ecsEntity.Get<DestroyOnHitComponent>();

            if (lifetime > 0)
                ecsEntity.Replace(new LifetimeComponent() { lifetimeSec = lifetime });
        }



        private void AddProjectileTag(in EcsEntity ecsEntity, bool isPlayerOwned)
        {
            ecsEntity.Get<Projectile>();

            if (isPlayerOwned)
                ecsEntity.Get<PlayerOwned>();
            else
                ecsEntity.Get<EnemyOwned>();
        }
    }
}