using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NullSceneLoader : ISceneLoader
{
    public void ToGame()
    {
        Debug.LogWarningFormat("Game started!");
    }

    public void ToMainMenu()
    {
        Debug.LogWarningFormat("To Main menu!");
    }

    public void ToGameOver()
    {
        Debug.LogWarningFormat("Game over!");
    }
}
