using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Game.ECS.SpawnProviders;
using Game.ECS.ObjectPool;
using Developed.PrefabPool;

public class SceneContext : MonoBehaviour, ISceneContext
{
    public ISpawnPlacementProvider spawnPlacement { get; private set; }

    public IGameObjectCreationProvider projectilesPool { get; private set; }
    public IGameObjectCreationProvider spaceEntitiesPool { get; private set; }

    public Bounds gameArea { get; private set; }

    public bool gameSessionInProgress { get; private set; } = false;


    [SerializeField] private MultiPrefabPool _projectilesPool;
    [SerializeField] private MultiPrefabPool _spaceEntitiesPool;

    [SerializeField] private RectTransform _floor;


    void Awake()
    {
        this.gameArea = new Bounds(_floor.position, _floor.rect.size);
        this.spawnPlacement = new EdgesSpawnHandler(gameArea);

        projectilesPool = new ExternalPoolAdapter(_projectilesPool);
        spaceEntitiesPool = new ExternalPoolAdapter(_spaceEntitiesPool);
    }


    public void ToggleGameSessionProgress(bool value) => this.gameSessionInProgress = value;
}