﻿namespace Game.ECS.Extentions
{
    public struct Timer<TTimerFlag>
        where TTimerFlag : struct
    {
        public float timeLeftSec;
    }
}