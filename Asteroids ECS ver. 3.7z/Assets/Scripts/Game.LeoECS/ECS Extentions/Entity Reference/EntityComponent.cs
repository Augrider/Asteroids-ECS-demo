namespace Game.ECS.Extentions
{
    [System.Serializable]
    public struct EntityComponent
    {
        public EcsEntityReference ecsEntityReference;
    }
}