using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IEntitySpawnProvider
{
    /// <summary>
    /// Instantiate object used in game
    /// </summary>
    GameObject GetNewGameObject(ISceneContext sceneContext, Vector3 position, Vector2 direction);

    /// <summary>
    /// Instantiate object with UniLeo blueprint
    /// </summary>
    void SetEntityComponents(in Leopotam.Ecs.EcsEntity ecsEntity, GameObject gameObject);
}