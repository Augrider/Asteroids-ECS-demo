using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IGameObjectCreationProvider
{
    GameObject GetNew(GameObject prefab);
    void SetFree(GameObject gameObject);
}
