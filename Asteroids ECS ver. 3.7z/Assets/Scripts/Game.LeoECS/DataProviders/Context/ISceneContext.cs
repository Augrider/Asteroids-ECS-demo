using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISceneContext
{
    ISpawnPlacementProvider spawnPlacement { get; }
    Bounds gameArea { get; }

    IGameObjectCreationProvider projectilesPool { get; }
    IGameObjectCreationProvider spaceEntitiesPool { get; }

    bool gameSessionInProgress { get; }

    void ToggleGameSessionProgress(bool value);
}